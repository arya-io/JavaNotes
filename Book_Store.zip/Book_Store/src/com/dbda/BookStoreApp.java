package com.dbda;

import java.time.LocalDate;
import java.util.Scanner;

public class BookStoreApp {
	public static void main(String []args) {
		
		InventoryManager manager = new InventoryManager();
		Scanner scanner = new Scanner(System.in);
		
		while(true) {
			System.out.println("\n1. Add New Book");
			System.out.println("2. Update Stock of a Book");
			System.out.println("3. Set Discount for All Books of a Given Category");
			System.out.println("4. Remove Books That Have Not Been in Stock for last 6 Months");
			System.out.println("5. Save Inventory to File");
			System.out.println("6. Load Inventory from File");
			System.out.println("7. Display All Books");
			System.out.println("8. Exit");
			System.out.println("Enter your choice: ");
			int choice = scanner.nextInt();
			
			try {
				switch (choice ) {
					case 1:
						System.out.print("Enter ID: ");
						String id = scanner.next();
						System.out.print("Enter Title: ");
						String title = scanner.next();
						System.out.print("Enter Author: ");
						String author = scanner.next();
						System.out.print("Enter Category (FICTION/NONFICTION/SCIENCE/HISTORY/TECHNOLOGY): ");
						Category category = Category.valueOf(scanner.next().toUpperCase());
						System.out.print("Enter Price: ");
						double price = scanner.nextDouble();
						System.out.print("Enter Stock: ");
						int stock = scanner.nextInt();
						
						System.out.print("Enter Publisher: ");
						String publisher = scanner.next();
						System.out.print("ENter Stock Update Date (YYYY-MM-DD): ");
						LocalDate stockUpdateDate = LocalDate.parse(scanner.next());
						manager.addBook(new Book(id, title, author, category, price, stock, stockUpdateDate, publisher));
						break;
						
					case 2:
						System.out.print("Enter ID to update stock: ");
						String stockId = scanner.next();
						System.out.print("Enter new Stock: ");
						int newStock = scanner.nextInt();
						manager.UpdateStock(stockId, newStock);
						break;
						
					case 3:
						System.out.print("Enter Category: ");
						Category discountCategory = Category.valueOf(scanner.next().toUpperCase());
						System.out.println("Enter Discount Percentage: ");
						double discount = scanner.nextDouble();
						manager.setDiscount(discountCategory, discount);
						break;
						
					case 4:
						manager.removeOldStock();
						break;
						
					case 5:
						manager.saveInventory();
						break;
						
					case 6:
						manager.loadInventory();
						break;
						
					case 7:
						manager.displayBooks();
						break;
						
					case 8:
						System.out.println("Exiting....");
						scanner.close();
						return;
						
					default:
						System.out.println("Enter valid option ");	
				}
			}catch (Exception e) {
				System.out.println("ERROR: "+e.getMessage());
			}
			
		}
	}
}
