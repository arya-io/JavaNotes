package com.dbda;

//Enum for Book Categories
public enum Category {
	FICTION, NONFICTION, SCIENCE, HISTORY, TECHNOLOGY;
}
