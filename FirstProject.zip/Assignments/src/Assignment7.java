
public class Assignment7 {

	public static void main(String[] args) {
		int array[] = { 50, -20, 30, 40, 60, 10 };
		if (array[0] == array[array.length - 1]) {
			System.out.println("First and last indexed element of array are same.");

		} else {
			System.out.println("First and last indexed element of array are not same.");

		}
	}

}
