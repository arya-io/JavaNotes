
public class Calculator {
	
	public int add(int num1, int num2) {
		
		return num1 + num2;
	}
	
	public int subtract(int num1, int num2) {
		
		return num1 - num2;
	}
	
	public int multiply(int num1, int num2) {
		
		return num1 * num2;
	}
	
	public int divide(int num1, int num2) {
		
		return num1 / num2;
	}
	
	public float add1(float num1, float num2) {
		
		return num1 + num2;
	}
	
	public float subtract1(float num1, float num2) {
		
		return num1 - num2;
	}
	
	public float multiply1(float num1, float num2) {
		
		return num1 * num2;
	}
	
	public float divide1(float num1, float num2) {
		
		return num1 / num2;
	}

}
