
public class Encrypt {

	public static void main(String[] args) {
		
		String username = ConsoleInput.getString();
		
		System.out.print("\nEncryption: ");

		for (int i = 0; i < username.length(); i++) {
			System.out.print((char)(username.charAt(i) + 65));
		}
		
		System.out.print("\nDecryption: ");
		
		for (int i = 0; i < username.length(); i++) {
			System.out.print(username.charAt(i));
		}
	}
}
