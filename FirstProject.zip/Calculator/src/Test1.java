public class Test1 {
	public static void main(String[] args) {
		
		for(int tmp = 0; tmp < args.length; tmp++) {
//			System.out.println(args[tmp]);
			System.out.println("HI");
		}
	}
}