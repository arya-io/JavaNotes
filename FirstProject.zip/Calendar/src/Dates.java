public class Dates{
	
	public static void main(String [] args) {
		
		private:
			
			int day, month, year;
		
		public:
			
			int getday() {
			
		}
	}
}