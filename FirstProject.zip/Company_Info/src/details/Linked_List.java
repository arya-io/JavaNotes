package details;

public class Linked_List {

	Node start;
	Node end;
	Node current;
	int maxCount;

	public void add(Employee data) {

		Node tmpNode = new Node(data);
		
		if (start == null) {
			start = end = current = tmpNode;
		}

		else {
			end.next = tmpNode;
			tmpNode.previous = end;
			end = tmpNode;
		}
		maxCount++;
	}

	public void displayAll() {
		
		Node temp = start;
		
		while (temp != null) {
			
			System.out.println("````````````````````");
			temp.data.displayDetails();
			temp = temp.next;
		}
	}
}


