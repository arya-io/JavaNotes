package details;

public class Node {
	
	Employee data;
	Node previous;
	Node next;

	public Node(Employee data) {
		
		this.data = data;
	}
}