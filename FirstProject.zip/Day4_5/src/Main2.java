
public class Main2 {

	public static void main(String[] args) {

		Triangle t = new Triangle(3, 4, 5);

		System.out.println("The perimeter of Triangle is: " + t.Perimeter());
		System.out.println("The area of Triangle is: " + t.Area());
	}
}
