
public class Main5 {
	
	public static void main(String [] args) {
		
		System.out.println("Name\tYears of Joining\t Salary\t\tAddress");
		
		Employee emp1 = new Employee("Robert", 1994, 1000000, "64C- WallStreet");
		Employee emp2 = new Employee("Sam", 2000, 1900000, "68D- WallStreet");
		Employee emp3 = new Employee("John", 1999, 2000000, "26B- WallStreet");
		
		emp1.show();
		emp2.show();
		emp3.show();
	}
}
