
public class Manager {

}
