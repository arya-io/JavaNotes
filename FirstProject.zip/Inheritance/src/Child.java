
public class Child extends Parent{

	public void showChild() {
		System.out.println("We are in Child Class.");
	}

}
