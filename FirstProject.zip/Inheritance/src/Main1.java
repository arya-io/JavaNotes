
public class Main1 {
	
	public static void main(String [] args) {
		
		Parent parentObj = new Parent();
		Child childObj = new Child();
		
		parentObj.showParent();
		childObj.showChild();
		childObj.showParent();
	}

}
