
public class Parent {

	public void showParent() {
		System.out.println("We are in Parent class.");
	}
}
