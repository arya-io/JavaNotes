
public class PrimeMembers extends Member{

	int JoiningYear, JoiningFees;
	boolean isActive;
	
	public void display() {
		
	}

	public int getJoiningYear() {
		return JoiningYear;
	}

	public void setJoiningYear(int joiningYear) {
		JoiningYear = joiningYear;
	}

	public int getJoiningFees() {
		return JoiningFees;
	}

	public void setJoiningFees(int joiningFees) {
		JoiningFees = joiningFees;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	
}
