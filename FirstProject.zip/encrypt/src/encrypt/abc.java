package encrypt;

public class abc {

}
