package profiles;

public abstract class Employee {
	protected String name, address, gender;
	protected int age;
	protected float basicSalary;

	public Employee(String name, String address, int age, String gender, float basicSalary) {
		this.name = name;
		this.address = address;
		this.age = age;
		this.gender = gender;
		this.basicSalary = basicSalary;
	}

	public void displayDetails() {
		System.out.println("Employee Name: " + this.getName());
		System.out.println("Employee Address: " + this.getAddress());
		System.out.println("Employee Age: " + this.getAge());
		System.out.println("Employee Gender: " + this.getGender());
		System.out.println("Employee Basic Salary: " + this.getBasicSalary());
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getGender() {
		return gender;
	}

	public int getAge() {
		return age;
	}

	public float getBasicSalary() {
		return basicSalary;
	}
}
