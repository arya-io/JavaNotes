//package profiles;
//
//import java.io.FileInputStream;
//import java.io.ObjectInputStream;
//import java.io.IOException;
//
//public class EmployeeDeserialization {
//
//    // Method to load employee list from file
//    public static Linked_List loadEmployeeList(String fileName) {
//        Linked_List employeeList = new Linked_List();
//        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName))) {
//            while (true) {
//                try {
//                    Employee employee = (Employee) in.readObject();  // Read each employee object
//                    employeeList.add(employee);
//                } catch (ClassNotFoundException e) {
//                    System.out.println("Class not found: " + e.getMessage());
//                } catch (IOException eof) {
//                    break;  // End of file reached
//                }
//            }
//            System.out.println("Employee list loaded from file: " + fileName);
//        } catch (IOException e) {
//            System.out.println("Error loading employee list: " + e.getMessage());
//        }
//        return employeeList;
//    }
//}
//
