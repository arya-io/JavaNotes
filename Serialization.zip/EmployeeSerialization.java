//package profiles;
//
//import java.io.FileOutputStream;
//import java.io.ObjectOutputStream;
//import java.io.IOException;
//
//public class EmployeeSerialization {
//
//    // Method to save employee list to file
//    public static void saveEmployeeList(Linked_List employeeList, String fileName) {
//        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName))) {
//            Node current = employeeList.start;
//            while (current != null) {
//                out.writeObject(current.data);  // Write each employee object to file
//                current = current.next;
//            }
//            System.out.println("Employee list saved to file: " + fileName);
//        } catch (IOException e) {
//            System.out.println("Error saving employee list: " + e.getMessage());
//        }
//    }
//}
//
