//package profiles;
//
//public abstract class Employee {
//    protected String name, address, gender;
//    protected int age;
//    protected float basicSalary;
//    private static final int SHIFT = 7;  // Shift value for simple encryption
//
//    public Employee(String name, String address, int age, String gender, float basicSalary) {
//        this.name = shiftEncrypt(name);  // Encrypt name
//        this.address = address;
//        this.age = age;
//        this.gender = gender;
//        this.basicSalary = basicSalary;
//    }
//
//    private String shiftEncrypt(String input) {
//        char[] encrypted = new char[input.length()];
//        for (int i = 0; i < input.length(); i++) {
//            encrypted[i] = (char) (input.charAt(i) + SHIFT);
//        }
//        return new String(encrypted);
//    }
//
//    private String shiftDecrypt(String input) {
//        char[] decrypted = new char[input.length()];
//        for (int i = 0; i < input.length(); i++) {
//            decrypted[i] = (char) (input.charAt(i) - SHIFT);
//        }
//        return new String(decrypted);
//    }
//
//    // Modify displayDetails to show decrypted name
//    public void displayDetails() {
//        System.out.println("Employee Name: " + shiftDecrypt(this.name));
//        System.out.println("Employee Address: " + this.getAddress());
//        System.out.println("Employee Age: " + this.getAge());
//        System.out.println("Employee Gender: " + this.getGender());
//        System.out.println("Employee Basic Salary: " + this.getBasicSalary());
//    }
//
//    public String getName() {
//        return shiftDecrypt(name);
//    }
//
//    public String getAddress() {
//        return address;
//    }
//
//    public String getGender() {
//        return gender;
//    }
//
//    public int getAge() {
//        return age;
//    }
//
//    public float getBasicSalary() {
//        return basicSalary;
//    }
//}
//
