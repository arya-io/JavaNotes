package profiles;

public class Engineer extends Employee {
	float overTime;

	public Engineer(String name, String address, int age, String gender, float basicSalary, float overTime) {
		super(name, address, age, gender, basicSalary);
		this.overTime = overTime;
	}

	@Override
	public void displayDetails() {
		super.displayDetails();
		System.out.println("Employee OverTime: " + this.overTime);
	}
}
