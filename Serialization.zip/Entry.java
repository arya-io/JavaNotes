package profiles;

public class Entry {
	public static void main(String[] args) {
		Linked_List employeeList = new Linked_List();
		int choice = 0, option = 0;
		final int ADD = 1, DISPLAY = 2, EXIT = 3;

		while (choice != EXIT) {
			System.out.println("\n1. Add");
			System.out.println("2. Display");
			System.out.println("3. Exit");
			System.out.println("\nEnter your choice: ");

			try {
				choice = ConsoleInput.getInteger();
			} catch (NumberFormatException e) {
				System.out.println("Invalid input! Please enter a valid integer.");
				continue;
			}

			switch (choice) {
			case ADD:
				while (option < 4) {
					System.out.println("\n1. Manager");
					System.out.println("2. Engineer");
					System.out.println("3. SalesPerson");
					System.out.println("4. Exit");
					System.out.println("\nEnter your choice: ");

					try {
						option = ConsoleInput.getInteger();
					} catch (NumberFormatException e) {
						System.out.println("Invalid input! Please enter a valid integer.");
						continue;
					}

					if (option < 4 && option > 0) {
						try {
							System.out.println("\nEnter Name: ");
							String name = ConsoleInput.getString();

							System.out.println("\nEnter Address: ");
							String address = ConsoleInput.getString();

							System.out.println("\nEnter Age: ");
							int age = ConsoleInput.getInteger(); // Wrap in try-catch

							System.out.println("\nEnter Gender: ");
							String gender = ConsoleInput.getString();

							System.out.println("\nEnter Basic Salary: ");
							float basicSalary = ConsoleInput.getFloat(); // Wrap in try-catch

							Employee employee = null;

							switch (option) {
							case 1:
								System.out.println("\nEnter HRA: ");
								float hra = ConsoleInput.getFloat(); // Wrap in try-catch
								employee = new Manager(name, address, age, gender, basicSalary, hra);
								break;
							case 2:
								System.out.println("Enter OverTime: ");
								float overTime = ConsoleInput.getFloat(); // Wrap in try-catch
								employee = new Engineer(name, address, age, gender, basicSalary, overTime);
								break;
							case 3:
								System.out.println("Enter Commission: ");
								float commission = ConsoleInput.getFloat(); // Wrap in try-catch
								employee = new SalesPerson(name, address, age, gender, basicSalary, commission);
								break;
							}

							if (employee != null) {
								employeeList.add(employee);
								System.out.println("\nRecords Added Successfully..!!\n");
							}
						} catch (NumberFormatException e) {
							System.out.println("Invalid input! Please enter numeric values where applicable.");
						}
					}
				}
				break;

			case DISPLAY:
				employeeList.displayAll();
				break;

			case EXIT:
				System.exit(0);
				break;
			}
		}
	}
}
