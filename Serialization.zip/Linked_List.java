package profiles;

public class Linked_List {
	Node start;
	Node end;
	Node current;
	int maxCount;

	public void add(Employee data) {
		Node tmpNode = new Node(data);
		if (start == null) {
			start = end = current = tmpNode;
		} else {
			end.next = tmpNode;
			tmpNode.previous = end;
			end = tmpNode;
		}
		maxCount++;
	}

	public void displayAll() {
		try {
			Node temp = start;
			if (temp == null) {
				throw new NullPointerException("No employees to display.");
			}
			while (temp != null) {
				System.out.println("````````````````````");
				temp.data.displayDetails();
				temp = temp.next;
			}
		} catch (NullPointerException e) {
			System.out.println(e.getMessage());
		}
	}
}